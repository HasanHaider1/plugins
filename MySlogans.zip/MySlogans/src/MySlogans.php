<?php declare(strict_types=1);

namespace MySlogans;

use Shopware\Core\Framework\Plugin;

class MySlogans extends Plugin
{
}